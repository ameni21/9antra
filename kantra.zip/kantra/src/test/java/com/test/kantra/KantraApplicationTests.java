package com.test.kantra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KantraApplicationTests {

	@Test
	void contextLoads() {
	}

}
