package com.test.kantra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KantraApplication {

	public static void main(String[] args) {
		SpringApplication.run(KantraApplication.class, args);
	}

}
