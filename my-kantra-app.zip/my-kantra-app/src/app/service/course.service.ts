import { Inject, Injectable } from '@angular/core';
import { Course } from '../shared/course';
import {HttpClient ,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class CourseService {
  /*courses : Course[] = []*/

  constructor(private httpClient: HttpClient,@Inject('BaseURL') private baseURL:string ) { }

  getCourses():Observable< Course[] >{
    return this.httpClient.get<Course[] >(this.baseURL);
  }

  getCourseById(id: number): Observable< Course>{
    return this.httpClient.get<Course>(`${this.baseURL}/${id}`);
  }
  
  deleteCourseById(id: number): Observable<any>{
    return this.httpClient.delete<any>(`${this.baseURL}/${id}`);
  
  }

  createCourse(course: Course): Observable<Course> {
    return this.httpClient.post<Course>(this.baseURL, course);
  }

  addCourses(course: Course): Observable< Course>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    console.log(course)
    return this.httpClient.post<Course>(this.baseURL + 'courses', course,httpOptions);

  }

  updateCourse(id: number, course: Course): Observable<Course> {
    return this.httpClient.put<Course>(`${this.baseURL}/${id}`, course);
  }
  
}
