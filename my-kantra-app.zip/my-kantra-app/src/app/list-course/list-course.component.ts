import { Component, OnInit } from '@angular/core';
import { Course } from '../shared/course';
import { CourseService } from '../service/course.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-list-course',
  templateUrl: './list-course.component.html',
  styleUrls: ['./list-course.component.css']
})
export class ListCourseComponent implements OnInit {
  
  courses: Course[] = [];

  constructor(private courseService: CourseService, private router : Router) { }

  ngOnInit(): void {
    this.getCourses();
  }

  getCourses(): void {
    this.courseService.getCourses().subscribe(courses => {
      this.courses = courses;
    });
  }

  deleteCourse(id: number): void {
    this.courseService.deleteCourseById(id).subscribe(() => {
      this.getCourses(); // Actualiser la liste des cours après la suppression
    });
  }

  updateCourse(id: number): void {
    
    //this.router.navigate(['/update-course', id]);
  }
  
  addCourse(){
    this.router.navigate(['/update-course'])
  }
  

}
