import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CourseService } from '../service/course.service';
import { Course } from '../shared/course';

@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit {

  constructor(private courseService: CourseService) { }

  ngOnInit(): void {
  }

  onSubmit(form: NgForm) {
    let course: Course = {
      id: form.value['id'],
      name: form.value['name'],
      image: form.value['image'],
      prix: form.value['prix']
      // Assurez-vous que les champs du modèle Course correspondent aux champs du formulaire
    };
  
    this.courseService.createCourse(course).subscribe((response) => {
      // Traitez la réponse ici si nécessaire
    });

}

}
