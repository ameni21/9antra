import {Course} from './course'
export const COURSES: Course[] = [
    
    {
        id: 1,
        name: "Spring Boot / Angular",
        image: "src/assets/img/spring.png",
        prix: 350
      },
      {
        id: 2,
        name: "Node JS / React",
        image: "src/assets/img/reactJS.png",
        prix: 350
      },
      {
        id: 3,
        name: "Flutter / Firebase",
        image: "src/assets/img/flutter.png",
        prix: 350
      },
      {
        id: 4,
        name: "Business Intelligence",
        image: "src/assets/img/bi.png",
        prix: 350
      },
      {
        id: 5,
        name: "Artificial Intelligence",
        image: "src/assets/img/ai.png",
        prix: 350
      },
      {
        "id": 6,
        "name": "Devops",
        "image": "src/assets/img/devops.png",
        prix: 350
      }
]