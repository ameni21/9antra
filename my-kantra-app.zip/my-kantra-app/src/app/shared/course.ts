export class Course {
    id?: number;
    image: string;
    name: string;
    prix: number;
    
    public constructor(id: number, image: string, name: string, prix: number){
        this.id = id;
        this.image = image;
        this.name = name;
        this.prix = prix;
    }
}
