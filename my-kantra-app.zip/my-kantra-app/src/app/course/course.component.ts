import { Component, Inject, OnInit } from '@angular/core';
import { Course } from '../shared/course';
import { CourseService } from '../service/course.service';
import { Router } from '@angular/router';
import { COURSES } from '../shared/courses';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  courses?: Course[] = [];
  COURSES1 = COURSES ;
  

  constructor(private courseService : CourseService, private router : Router ) { }

  ngOnInit(): void {
    this.courseService.getCourses();
  }

  /*onCourses(){
    this.router.navigate(['/courses']);
  }*/

}

