import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { CourseComponent } from './course/course.component';
import { ListCourseComponent } from './list-course/list-course.component';
import { UpdateCourseComponent } from './update-course/update-course.component';


const routes: Routes = [
  {path: "home", component: HomeComponent},
  {path: "contact", component: ContactComponent},
  {path: "course", component: CourseComponent},
  {path: "list-course", component: ListCourseComponent},
  {path:"update-course", component: UpdateCourseComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
