import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BaseURL } from './shared/baseUrl';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { CourseComponent } from './course/course.component';
import { CourseService } from './service/course.service';
import { FormsModule } from '@angular/forms';
import { ListCourseComponent } from './list-course/list-course.component';
import { UpdateCourseComponent } from './update-course/update-course.component';



@NgModule({
  declarations: [

    AppComponent,
    HomeComponent,
    ContactComponent,
    CourseComponent,
    ListCourseComponent,
    UpdateCourseComponent,
    
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [CourseService,{provide :'BaseURL', useValue: BaseURL}],
  bootstrap: [AppComponent]
})
export class AppModule { }
